const List_1 = ["Arjun", "Adwait", "Swapnil", "Amit", "Vishal", "Adan"];
const List_2 = ["Adwait", "Laxman", "Amit", "Adan", "Nitin", "Gaurav"];

const uniqueSetOfList1NotInList2 = []
const uniqueSetOfList2NotInList1 = []
const setOfUserPresentInBothList1AndList2 = []

for (let i of List_1) {
    if (List_2.includes(i)) {
        continue;
    } else {
        uniqueSetOfList1NotInList2.push(i)
    }
}

for (let j of List_2) {
    if (List_1.includes(j)) {
        continue;
    } else {
        uniqueSetOfList2NotInList1.push(j)
    }
}

for (let k of List_1) {
    if (List_2.includes(k)) {
        setOfUserPresentInBothList1AndList2.push(k)
    }
}


console.log(uniqueSetOfList1NotInList2)
console.log(uniqueSetOfList2NotInList1)
console.log(setOfUserPresentInBothList1AndList2)